import React from "react";

export default function No_access() {
  return (
    <div className="flex flex-1 justify-center items-center h-screen bg-red-400">
      <div className="flex text-3xl font-bold text-gray-800">Access Denied</div>
    </div>
  );
}
